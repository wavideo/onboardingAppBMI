package com.example.mybmi_calculator

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.pow
import kotlin.math.round

class ResultActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_result)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val height = intent.getIntExtra("height", 0)
        val weight = intent.getIntExtra("weight", 0)

        var value = weight / (height / 100.0).pow(2.0)
        value = round(value*10)/10

        var resultText = ""
        var resImg = 0
        var resColor = 0

        if ( value < 18.5 ) {
            resultText = "저체중"
            resImg = R.drawable.img_lv1
            resColor = Color.RED
        } else if ( value >= 18.5 && value < 23.0 ) {
            resultText = "정상체중"
            resImg = R.drawable.img_lv2
            resColor = Color.BLACK
        } else if ( value >= 23.0 && value < 25.5 ) {
            resultText = "과체중"
            resImg = R.drawable.img_lv3
            resColor = Color.BLACK
        } else if ( value >= 25.5 && value < 30.0 ) {
            resultText = "경도비만"
            resImg = R.drawable.img_lv4
            resColor = Color.RED
        } else if ( value >= 30.0 && value < 35.0 ) {
            resultText = "중정도비만"
            resImg = R.drawable.img_lv5
            resColor = Color.RED
        } else if ( value >= 35.0 ) {
            resultText = "고도비만"
            resImg = R.drawable.img_lv6
            resColor = Color.RED
        }

        //화면에 입히기
        val tv_resvalue= findViewById<TextView>(R.id.tv_resvalue)
        val tv_restext= findViewById<TextView>(R.id.tv_restext)
        val iv_image= findViewById<ImageView>(R.id.iv_image)
        val btn_back= findViewById<Button>(R.id.btn_back)

        tv_resvalue.text = value.toString()
        tv_restext.text = resultText
        iv_image.setImageResource(resImg)
        tv_restext.setTextColor(resColor)

        btn_back.setOnClickListener {
            finish()
        }

    }
}