package com.example.mybmi_calculator

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.pow
import kotlin.math.round

class ResultActivity_1차연습 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_result)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 인텐트 값을 받아옵시다. ("이름", 기본값) 형태입니다.
        val height = intent.getIntExtra("height", 0)
        val weight = intent.getIntExtra("weight", 0)

        // 결과 계산식
        var value = weight / (height / 100.0).pow(2.0) // cm를 M로 바꾸기 위해, pow는 제곱 메서드
        value = round(value*10)/10
        // round는 소수점 떨구기 메소드입니다. 작동 안하면 "import.kotilin.math.~"로 수식을 불러와야해요

        // 바꿔치기할 변수 리스트
        var resultText = ""
        var resultImage = 0
        var resultColor = 0

        // 상황별 변수 대응
        if (value < 18.5) {
            resultText = "저체중"
            resultImage = R.drawable.img_lv1
            resultColor = Color.RED
        } else if (value >= 18.5 && value < 23.0) {
            resultText = "정상체중"
            resultImage = R.drawable.img_lv2
            resultColor = Color.GREEN
        } else if (value >= 23.0 && value < 25.5) {
            resultText = "과체중"
            resultImage = R.drawable.img_lv3
            resultColor = Color.BLACK
        } else if (value >= 25.5 && value < 30.0) {
            resultText = "경도비만"
            resultImage = R.drawable.img_lv4
            resultColor = Color.BLACK
        } else if (value >= 30.0 && value < 35.0) {
            resultText = "중정도비만"
            resultImage = R.drawable.img_lv5
            resultColor = Color.RED
        } else if (value >=35.0) {
            resultText = "고도비만"
            resultImage = R.drawable.img_lv6
            resultColor = Color.RED
        }

        // 화면 끌어오기
        val tv_resvalue = findViewById<TextView>(R.id.tv_resvalue)
        val tv_restext = findViewById<TextView>(R.id.tv_restext)
        val iv_image = findViewById<ImageView>(R.id.iv_image)
        val btn_back = findViewById<Button>(R.id.btn_back)

        // 각 화면의 "텍스트" 속성에, 변수를 대입합니다
        tv_resvalue.text = value.toString() // Int 값을 text로 반환하기 위해, toString을 씁니다
        tv_restext.text = resultText
        // 아미지, 컬러를 대입하는 메소드 ".set 이미지리소스/텍스트컬러()" 를 사용합니다
        iv_image.setImageResource(resultImage)
        tv_restext.setTextColor(resultColor)

        // 클릭하면 - 피니쉬
        btn_back.setOnClickListener {
            finish()
        }

    }
}