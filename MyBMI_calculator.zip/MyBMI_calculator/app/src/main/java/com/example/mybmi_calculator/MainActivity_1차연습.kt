package com.example.mybmi_calculator

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity_1차연습 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)

            // 반환값으로 insets를 반환합니다.
            insets
        }

        // 여기에 최상위 수준 선언을 추가하세요.


        //계산에 쓸 숫자, 누르게 될 버튼 등 "상호작용"에 필요한 모든 것을 미리 선언해둘거야
            val heightEditText = findViewById<EditText>(R.id.et_height)
            val weightEditText = findViewById<EditText>(R.id.et_weight)
            val submitButton = findViewById<Button>(R.id.btn_check)
            /*findViewById로 화면에 있는 요소를 끌어왔어
            <타입>과 함께 (R.id.이름)을 설정해서 필요한 개체를 찾았어 */


            /* "버튼"에 대해 "클릭 리스너"라는 안드로이드 프레임워크 함수를 쓸 거야.
            * 변수.함수{}의 형태로 작성했어 */
            submitButton.setOnClickListener {

                //만약 변수의. "text" 값이. 비어있으면()
                //Toast 메서드는 (컨택스트, 텍스트, 듀레이션)으로 구성되어 있어
                if(heightEditText.text.isEmpty()) {
                    Toast.makeText(this,"신장을 입력해주세요", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                //show 메서드를 나중에 쓰고 싶다면, val toast = Toast ... 로 변수를 지정한 뒤, toast.show로 여러번 써먹어도 좋아.
                if(weightEditText.text.isEmpty()) {
                    Toast.makeText(this,"체중을 입력해주세요", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                //변수의. "수정가능한 text"값을. String으로 바꾼 다음, Int로 바꾼다.
                val height:Int = heightEditText.text.toString().toInt()
                val weight:Int = weightEditText.text.toString().toInt()

                /* Intent는 액티비티 전환을 위해 사용하는 "클래스"야. 그래서 대문자를 써야해.
                this _ 현재 액티비티의 속성을, ResultActivity::class.java 라는 액티비티로 옮기겠다 */
                val intent = Intent(this, ResultActivity::class.java)

                /*intent.putExtra("이름", 변수)
                putExtra 메서드로 intent 클래스에 속성을 추가할거야
                "이름"과 불러올 변수를 언급하면 돼 */
                intent.putExtra("height",height)
                intent.putExtra("weight",weight)

                startActivity(intent)

            }
        }
    }