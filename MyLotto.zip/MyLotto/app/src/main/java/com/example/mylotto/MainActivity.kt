package com.example.mylotto

import android.os.Bundle
import android.widget.Button
import android.widget.NumberPicker
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible
import org.w3c.dom.Text
import java.security.KeyStore.TrustedCertificateEntry

class MainActivity : AppCompatActivity() {

    // onCreate 전에, 필요한 layout 요소를 미리 불러와두겠습니다. 당장은 아니고, 이따 선언할 때 쓸 거예요
    private val clearButton by lazy { findViewById<Button>(R.id.btn_clear) }
    private val addButton by lazy { findViewById<Button>(R.id.btn_add) }
    private val randomButton by lazy { findViewById<Button>(R.id.btn_random) }
    private val numPick by lazy { findViewById<NumberPicker>(R.id.np_num) }

    // List<TextView> 자료형을 선언합니다.
    private val numTextViewList: List<TextView> by lazy {
        listOf<TextView>(
            findViewById(R.id.tv_num1),
            findViewById(R.id.tv_num2),
            findViewById(R.id.tv_num3),
            findViewById(R.id.tv_num4),
            findViewById(R.id.tv_num5),
            findViewById(R.id.tv_num6)
        )
    }

    // 이따 쓸 변수도 미리 설정해둡시다. 로직은 안짜도 되니까 일단 "빈칸"만 뚫어두자고요
    private var didRun = false  // random 여부를 체크
    private val pickNumberSet = hashSetOf<Int>()   // 선택한 넘버 리스트.
    //// hashSetOf 는 순서무관, 중복없이 리스트를 만들어야 할 때 쓰기 좋은 함수입니다 !


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main) // R.layout.activity_main 대신 R.layout.main을 사용
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //메인 함수는 이게 끝이야

        numPick.minValue = 1
        numPick.maxValue = 45

        initAddButton()
        initRandomButton()
        initClearButton()

    }

    // 괄호 밖에서, 미리 함수를 설정해둡니다

    private fun initAddButton() {
        addButton.setOnClickListener {
            when {
                didRun -> showToast("초기화 후에 시도해주세요.")
                pickNumberSet.size >= 5 -> showToast("숫자는 최대 5개까지 선택할 수 있습니다.")
                pickNumberSet.contains(numPick.value) -> showToast("이미 선택된 숫자입니다")
                else -> {
                    // 리스트에 방금 추가된, 최신 index 순서의 숫자를 textView로 선언합니다.
                    val textView = numTextViewList[pickNumberSet.size] // [대괄호]는 리스트의 순서를 특정할 때 씁니다
                    textView.isVisible = true
                    textView.text = numPick.value.toString()
                    setNumBack(numPick.value, textView)
                    pickNumberSet.add(numPick.value)
                }
            }
        }
    }

    private fun initClearButton() {
        clearButton.setOnClickListener {
            pickNumberSet.clear()
            numTextViewList.forEach { it.isVisible = false }
            didRun = false
            numPick.value = 1
        }
    }

    private fun initRandomButton() {
        randomButton.setOnClickListener {
            val list = getRandom()

            didRun = true

            list.forEachIndexed { index, number ->
                val textView = numTextViewList[index]
                textView.text = number.toString()
                textView.isVisible = true
                setNumBack(number, textView)
            }

        }
    }

    // numPick의 크기에 따라, circle의 배경색을 바꿔주는 함수
    private fun setNumBack(number: Int, textView: TextView) {
        val background = when (number) {
            in 1..10 -> R.drawable.circle_yellow
            in 11..20 -> R.drawable.circle_blue
            in 21..30 -> R.drawable.circle_red
            in 31..40 -> R.drawable.circle_gray
            else -> R.drawable.circle_green
        }
        textView.background = ContextCompat.getDrawable(this, background)
    }

    // 넘버스 목록 중 셔플해서 픽넘셋에 추가
    private fun getRandom(): List<Int> {
        val numbers = (1..45).filter { it !in pickNumberSet }
        return (pickNumberSet + numbers.shuffled().take(6 - pickNumberSet.size)).sorted()
    }

    // 경고문 띄우기
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
